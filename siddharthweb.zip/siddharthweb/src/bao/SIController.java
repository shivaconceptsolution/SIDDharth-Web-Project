package bao;





import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Request;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import dao.SI;

@Controller
public class SIController {
@RequestMapping("/siview")	
public ModelAndView siLoad()
{
	return new ModelAndView("siview","command",new SI());
}
@RequestMapping("/silogic")	
public ModelAndView siLogic(@ModelAttribute("siddharthweb")SI obj, ModelMap model)
{
	Configuration cfg= new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SI s = new SI();
	s.setP(obj.getP());
	s.setR(obj.getR());
	s.setT(obj.getT());
	float si = (obj.getP()*obj.getR()*obj.getT())/100;
	s.setSi(si);
	SessionFactory sf = cfg.buildSessionFactory();
	Session ss = sf.openSession();
	Transaction tx = ss.beginTransaction();
	ss.save(s);
	tx.commit();
	ss.close();
	
	
	
	return new ModelAndView("siresult","msg",si);
}
@RequestMapping("/viewrecord")	
public ModelAndView siDisplayView()
{
	return new ModelAndView("sidisplayview");
}
@RequestMapping("/editsi")	
public ModelAndView editSI(HttpServletRequest request, HttpServletResponse response)
{
	Configuration cfg= new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory sf = cfg.buildSessionFactory();
	Session ss = sf.openSession();
	Query q = ss.createQuery("from SI s where s.id=?");
	q.setInteger(0,Integer.parseInt(request.getParameter("q")));
	List lst = q.list();
	ss.close();
	ModelAndView mo= new ModelAndView("editsi");
	mo.addObject("res",lst);
	return mo;
}

@RequestMapping("/siedit")	
public ModelAndView siEdit(HttpServletRequest request,HttpServletResponse response)
{
	Configuration cfg= new Configuration();
	cfg.configure("hibernate.cfg.xml");
	/*SI s = new SI();
	s.setP(obj.getP());
	s.setR(obj.getR());
	s.setT(obj.getT());
	float si = (obj.getP()*obj.getR()*obj.getT())/100;
	s.setSi(si);*/
	SessionFactory sf = cfg.buildSessionFactory();
	Session ss = sf.openSession();
	SI s = (SI)ss.get(SI.class,Integer.parseInt(request.getParameter("txtid")));
	s.setP(Float.parseFloat(request.getParameter("txtp")));
	s.setR(Float.parseFloat(request.getParameter("txtr")));
	s.setT(Float.parseFloat(request.getParameter("txtt")));
	s.setSi(Float.parseFloat(request.getParameter("txtsi")));
	Transaction tx = ss.beginTransaction();
	ss.save(s);
	tx.commit();
	ss.close();
	
	
	
	return new ModelAndView("redirect:viewrecord.do");
}
}
